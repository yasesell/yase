import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { useNotes } from '../context/NoteContext';
import Button from '../components/ui/Button';
import NoteCard from '../components/notes/NoteCard';
import NoteDetail from '../components/notes/NoteDetail';
import NoteForm from '../components/notes/NoteForm';
import NotesFilter from '../components/notes/NotesFilter';
import Modal from '../components/ui/Modal';
import { NoteFilters, Note } from '../types';
import { 
  Bell, Calendar, FileText, Inbox, LogOut, Plus, ShoppingBag, ShoppingCart, 
  Package, Users, Menu, ChevronRight, ChevronLeft 
} from 'lucide-react';

const DashboardPage: React.FC = () => {
  const { user, logout } = useAuth();
  const { notes, isLoading, filterNotes, categories, priorities } = useNotes();
  
  const [selectedNote, setSelectedNote] = useState<Note | null>(null);
  const [showAddNoteModal, setShowAddNoteModal] = useState(false);
  const [showNoteDetailModal, setShowNoteDetailModal] = useState(false);
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [activeFilters, setActiveFilters] = useState<NoteFilters>({});
  const [filteredNotes, setFilteredNotes] = useState<Note[]>(notes);
  
  React.useEffect(() => {
    setFilteredNotes(filterNotes(activeFilters));
  }, [notes, activeFilters, filterNotes]);
  
  const handleFilter = (filters: NoteFilters) => {
    setActiveFilters(filters);
  };
  
  const handleNoteClick = (note: Note) => {
    setSelectedNote(note);
    setShowNoteDetailModal(true);
  };
  
  const handleAddNote = () => {
    setShowAddNoteModal(true);
  };
  
  const handleLogout = () => {
    if (confirm('Çıkış yapmak istediğinizden emin misiniz?')) {
      logout();
    }
  };
  
  const closeNoteDetailModal = () => {
    setShowNoteDetailModal(false);
    setSelectedNote(null);
  };
  
  const getNoteCountByCategory = (category: string) => {
    return notes.filter(note => note.category === category).length;
  };

  const getUnreadCount = () => {
    return notes.filter(note => !note.isRead).length;
  };
  
  return (
    <div className="min-h-screen bg-gray-100 flex">
      {/* Sidebar */}
      <div className={`bg-white shadow-md z-20 transition-all duration-300 ${
        sidebarOpen ? 'w-64' : 'w-20'
      } fixed h-full`}>
        <div className="p-4 border-b flex items-center justify-between">
          <div className={`flex items-center ${!sidebarOpen && 'justify-center w-full'}`}>
            <ShoppingBag size={24} className="text-blue-600" />
            {sidebarOpen && <span className="ml-2 font-bold text-lg">Amazon Yönetim</span>}
          </div>
          <button 
            onClick={() => setSidebarOpen(!sidebarOpen)}
            className="text-gray-500 hover:text-gray-700 p-1 rounded-full hover:bg-gray-100"
          >
            {sidebarOpen ? <ChevronLeft size={20} /> : <ChevronRight size={20} />}
          </button>
        </div>
        
        <div className="p-4">
          <ul className="space-y-2">
            <li>
              <a 
                href="#" 
                className="flex items-center p-2 rounded-md hover:bg-blue-50 text-gray-700 hover:text-blue-600 group"
              >
                <Inbox size={20} className="group-hover:text-blue-600" />
                {sidebarOpen && <span className="ml-3">Gelen Kutusu</span>}
                {sidebarOpen && getUnreadCount() > 0 && (
                  <span className="ml-auto bg-blue-100 text-blue-800 text-xs py-0.5 px-2 rounded-full">
                    {getUnreadCount()}
                  </span>
                )}
              </a>
            </li>
            <li>
              <a 
                href="#" 
                className="flex items-center p-2 rounded-md hover:bg-blue-50 text-gray-700 hover:text-blue-600 group"
              >
                <ShoppingCart size={20} className="group-hover:text-blue-600" />
                {sidebarOpen && <span className="ml-3">Siparişler</span>}
                {sidebarOpen && getNoteCountByCategory('orders') > 0 && (
                  <span className="ml-auto bg-gray-100 text-gray-700 text-xs py-0.5 px-2 rounded-full">
                    {getNoteCountByCategory('orders')}
                  </span>
                )}
              </a>
            </li>
            <li>
              <a 
                href="#" 
                className="flex items-center p-2 rounded-md hover:bg-blue-50 text-gray-700 hover:text-blue-600 group"
              >
                <Package size={20} className="group-hover:text-blue-600" />
                {sidebarOpen && <span className="ml-3">Stok</span>}
                {sidebarOpen && getNoteCountByCategory('inventory') > 0 && (
                  <span className="ml-auto bg-gray-100 text-gray-700 text-xs py-0.5 px-2 rounded-full">
                    {getNoteCountByCategory('inventory')}
                  </span>
                )}
              </a>
            </li>
            <li>
              <a 
                href="#" 
                className="flex items-center p-2 rounded-md hover:bg-blue-50 text-gray-700 hover:text-blue-600 group"
              >
                <Users size={20} className="group-hover:text-blue-600" />
                {sidebarOpen && <span className="ml-3">Müşteriler</span>}
                {sidebarOpen && getNoteCountByCategory('customer') > 0 && (
                  <span className="ml-auto bg-gray-100 text-gray-700 text-xs py-0.5 px-2 rounded-full">
                    {getNoteCountByCategory('customer')}
                  </span>
                )}
              </a>
            </li>
            <li>
              <a 
                href="#" 
                className="flex items-center p-2 rounded-md hover:bg-blue-50 text-gray-700 hover:text-blue-600 group"
              >
                <FileText size={20} className="group-hover:text-blue-600" />
                {sidebarOpen && <span className="ml-3">Tüm Notlar</span>}
              </a>
            </li>
            <li>
              <a 
                href="#" 
                className="flex items-center p-2 rounded-md hover:bg-blue-50 text-gray-700 hover:text-blue-600 group"
              >
                <Calendar size={20} className="group-hover:text-blue-600" />
                {sidebarOpen && <span className="ml-3">Takvim</span>}
              </a>
            </li>
          </ul>
        </div>
      </div>
      
      {/* Main Content */}
      <div className={`flex-1 transition-all duration-300 ${
        sidebarOpen ? 'ml-64' : 'ml-20'
      }`}>
        {/* Header */}
        <header className="bg-white shadow-sm">
          <div className="flex items-center justify-between p-4">
            <div className="flex items-center">
              <button 
                className="md:hidden p-2 mr-2 rounded-md text-gray-700 hover:bg-gray-100"
                onClick={() => setSidebarOpen(!sidebarOpen)}
              >
                <Menu size={20} />
              </button>
              <h1 className="text-lg font-medium">Not Defteri</h1>
            </div>
            
            <div className="flex items-center space-x-4">
              <div className="relative">
                <button className="p-2 rounded-full text-gray-700 hover:bg-gray-100 relative">
                  <Bell size={20} />
                  <span className="absolute top-0 right-0 h-2 w-2 bg-red-500 rounded-full"></span>
                </button>
              </div>
              
              <div className="flex items-center">
                {user && (
                  <>
                    <img 
                      src={user.avatar || `https://ui-avatars.com/api/?name=${user.username}&background=random`} 
                      alt={user.username}
                      className="h-8 w-8 rounded-full mr-2"
                    />
                    <span className="hidden md:inline font-medium">{user.username}</span>
                  </>
                )}
                
                <button 
                  onClick={handleLogout}
                  className="ml-4 p-2 rounded-md text-gray-700 hover:bg-gray-100 hover:text-red-600"
                  title="Çıkış Yap"
                >
                  <LogOut size={20} />
                </button>
              </div>
            </div>
          </div>
        </header>
        
        {/* Content */}
        <main className="p-4">
          <div className="mb-4 flex justify-between items-center">
            <h2 className="text-xl font-semibold">Notlar</h2>
            <Button
              onClick={handleAddNote}
              variant="primary"
              icon={<Plus size={16} />}
            >
              Yeni Not
            </Button>
          </div>
          
          <NotesFilter
            onFilter={handleFilter}
            categories={categories}
            priorities={priorities}
          />
          
          <div className="mt-4">
            {isLoading ? (
              <div className="text-center py-8">
                <div className="animate-spin mx-auto h-8 w-8 border-4 border-blue-500 border-t-transparent rounded-full"></div>
                <p className="mt-2 text-gray-600">Notlar yükleniyor...</p>
              </div>
            ) : filteredNotes.length === 0 ? (
              <div className="text-center py-12 bg-white rounded-lg shadow-sm">
                <FileText size={48} className="mx-auto text-gray-400 mb-3" />
                <h3 className="text-lg font-medium text-gray-900 mb-1">Not bulunamadı</h3>
                <p className="text-gray-600">
                  {Object.keys(activeFilters).length > 0 
                    ? 'Filtrelere uyan not bulunamadı. Filtreleri değiştirerek tekrar deneyin.'
                    : 'Henüz not eklenmemiş. Yeni not eklemek için "Yeni Not" butonuna tıklayın.'}
                </p>
              </div>
            ) : (
              <div>
                {filteredNotes.map(note => (
                  <NoteCard
                    key={note.id}
                    note={note}
                    onClick={() => handleNoteClick(note)}
                  />
                ))}
              </div>
            )}
          </div>
        </main>
      </div>
      
      {/* Add Note Modal */}
      <Modal
        isOpen={showAddNoteModal}
        onClose={() => setShowAddNoteModal(false)}
        title="Yeni Not Ekle"
        size="lg"
      >
        <NoteForm
          onSave={() => setShowAddNoteModal(false)}
          onCancel={() => setShowAddNoteModal(false)}
        />
      </Modal>
      
      {/* Note Detail Modal */}
      <Modal
        isOpen={showNoteDetailModal}
        onClose={closeNoteDetailModal}
        title={selectedNote?.title}
        size="lg"
      >
        {selectedNote && (
          <NoteDetail
            note={selectedNote}
            onClose={closeNoteDetailModal}
          />
        )}
      </Modal>
    </div>
  );
};

export default DashboardPage;