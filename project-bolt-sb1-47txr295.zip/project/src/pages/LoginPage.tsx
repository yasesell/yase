import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import LoginForm from '../components/auth/LoginForm';
import TwoFactorForm from '../components/auth/TwoFactorForm';
import { ShoppingBag } from 'lucide-react';

const LoginPage: React.FC = () => {
  const { isAuthenticated } = useAuth();
  const [showTwoFactor, setShowTwoFactor] = useState(false);

  if (isAuthenticated) {
    window.location.href = '/dashboard';
    return null;
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 flex flex-col justify-center items-center p-4">
      <div className="w-full max-w-md bg-white rounded-xl shadow-lg overflow-hidden">
        <div className="p-8">
          <div className="flex justify-center mb-6">
            <div className="h-16 w-16 bg-blue-600 text-white rounded-full flex items-center justify-center">
              <ShoppingBag size={32} />
            </div>
          </div>
          
          {!showTwoFactor ? (
            <LoginForm onSuccess={() => setShowTwoFactor(true)} />
          ) : (
            <TwoFactorForm />
          )}
        </div>
      </div>
      
      <p className="mt-8 text-center text-sm text-gray-600">
        Amazon Mağaza Yönetim Sistemi &copy; {new Date().getFullYear()}
      </p>
    </div>
  );
};

export default LoginPage;