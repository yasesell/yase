import React from 'react';
import { AuthProvider } from './context/AuthContext';
import { NoteProvider } from './context/NoteContext';
import LoginPage from './pages/LoginPage';
import DashboardPage from './pages/DashboardPage';
import { useAuth } from './context/AuthContext';

const AppRoutes: React.FC = () => {
  const { isAuthenticated, isLoading } = useAuth();

  if (isLoading) {
    return (
      <div className="min-h-screen flex justify-center items-center bg-gray-100">
        <div className="animate-spin h-12 w-12 border-4 border-blue-500 border-t-transparent rounded-full"></div>
      </div>
    );
  }

  return isAuthenticated ? <DashboardPage /> : <LoginPage />;
};

function App() {
  return (
    <AuthProvider>
      <NoteProvider>
        <AppRoutes />
      </NoteProvider>
    </AuthProvider>
  );
}

export default App;