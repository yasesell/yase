// Authentication Types
export interface User {
  id: string;
  username: string;
  email: string;
  avatar?: string;
}

export interface AuthState {
  user: User | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  error: string | null;
}

// Note Types
export type NotePriority = 'urgent' | 'normal' | 'info';
export type NoteCategory = 'orders' | 'inventory' | 'customer' | 'marketing' | 'other';

export interface Note {
  id: string;
  title: string;
  content: string;
  createdAt: string;
  updatedAt: string;
  authorId: string;
  authorName: string;
  priority: NotePriority;
  category: NoteCategory;
  isRead: boolean;
  attachments: Attachment[];
  tags: string[];
}

export interface Attachment {
  id: string;
  filename: string;
  url: string;
  type: string;
  size: number;
}

export interface NoteFilters {
  search?: string;
  category?: NoteCategory;
  priority?: NotePriority;
  isRead?: boolean;
  startDate?: string;
  endDate?: string;
  authorId?: string;
}