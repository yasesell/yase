import React, { useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import Input from '../ui/Input';
import Button from '../ui/Button';
import { AlertCircle, Lock, Mail } from 'lucide-react';

interface LoginFormProps {
  onSuccess?: () => void;
}

const LoginForm: React.FC<LoginFormProps> = ({ onSuccess }) => {
  const { login, error, isLoading } = useAuth();
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [formErrors, setFormErrors] = useState<Record<string, string>>({});

  const validate = () => {
    const errors: Record<string, string> = {};
    if (!username.trim()) {
      errors.username = 'Kullanıcı adı gereklidir';
    }
    if (!password) {
      errors.password = 'Şifre gereklidir';
    }
    setFormErrors(errors);
    return Object.keys(errors).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!validate()) return;

    try {
      await login(username, password);
      if (onSuccess) {
        onSuccess();
      }
    } catch (err) {
      // Error is handled by the context
    }
  };

  return (
    <div className="w-full max-w-md">
      <form onSubmit={handleSubmit} className="space-y-4">
        <div className="text-center mb-6">
          <h1 className="text-2xl font-bold text-gray-900 mb-2">Yönetici Girişi</h1>
          <p className="text-gray-600">Amazon mağaza yönetim sistemine hoş geldiniz</p>
        </div>

        <Input
          label="Kullanıcı Adı"
          type="text"
          value={username}
          onChange={(e) => setUsername(e.target.value)}
          error={formErrors.username}
          icon={<Mail size={18} />}
          placeholder="Kullanıcı adınızı girin"
        />

        <Input
          label="Şifre"
          type="password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          error={formErrors.password}
          icon={<Lock size={18} />}
          placeholder="Şifrenizi girin"
        />

        {error && (
          <div className="p-3 bg-red-50 text-red-700 rounded-md flex items-center">
            <AlertCircle size={18} className="mr-2" />
            <span>{error}</span>
          </div>
        )}

        <Button
          type="submit"
          variant="primary"
          isLoading={isLoading}
          fullWidth
        >
          Giriş Yap
        </Button>

        <div className="text-center text-sm text-gray-600 mt-4">
          <p>Demo hesapları:</p>
          <p className="font-medium">Kullanıcı: admin1 / Şifre: password1</p>
          <p className="font-medium">Kullanıcı: admin2 / Şifre: password2</p>
        </div>
      </form>
    </div>
  );
};

export default LoginForm;