import React, { useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import Input from '../ui/Input';
import Button from '../ui/Button';
import { AlertCircle, KeyRound } from 'lucide-react';

interface TwoFactorFormProps {
  onSuccess?: () => void;
}

const TwoFactorForm: React.FC<TwoFactorFormProps> = ({ onSuccess }) => {
  const { verify2FA, error, isLoading } = useAuth();
  const [code, setCode] = useState('');
  const [formError, setFormError] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!code.trim()) {
      setFormError('Doğrulama kodu gereklidir');
      return;
    }
    
    if (code.length !== 6 || !/^\d+$/.test(code)) {
      setFormError('Geçerli bir 6 haneli kod girin');
      return;
    }
    
    try {
      const success = await verify2FA(code);
      if (success && onSuccess) {
        onSuccess();
      }
    } catch (err) {
      // Error is handled by the context
    }
  };

  return (
    <div className="w-full max-w-md">
      <form onSubmit={handleSubmit} className="space-y-4">
        <div className="text-center mb-6">
          <h1 className="text-2xl font-bold text-gray-900 mb-2">İki Faktörlü Doğrulama</h1>
          <p className="text-gray-600">Lütfen size gönderilen 6 haneli doğrulama kodunu girin</p>
        </div>

        <Input
          label="Doğrulama Kodu"
          type="text"
          value={code}
          onChange={(e) => {
            // Only allow digits and limit to 6 characters
            const value = e.target.value.replace(/\D/g, '').slice(0, 6);
            setCode(value);
            setFormError('');
          }}
          error={formError}
          icon={<KeyRound size={18} />}
          placeholder="6 haneli kodu girin"
          maxLength={6}
        />

        {error && (
          <div className="p-3 bg-red-50 text-red-700 rounded-md flex items-center">
            <AlertCircle size={18} className="mr-2" />
            <span>{error}</span>
          </div>
        )}

        <Button
          type="submit"
          variant="primary"
          isLoading={isLoading}
          fullWidth
        >
          Doğrula
        </Button>

        <div className="text-center text-sm text-gray-600 mt-4">
          <p>Demo için herhangi bir 6 haneli sayı girin (örn: 123456)</p>
        </div>
      </form>
    </div>
  );
};

export default TwoFactorForm;