import React, { useState } from 'react';
import { NoteFilters, NoteCategory, NotePriority } from '../../types';
import Button from '../ui/Button';
import Input from '../ui/Input';
import { Calendar, Filter, Search, X } from 'lucide-react';

interface NotesFilterProps {
  onFilter: (filters: NoteFilters) => void;
  categories: NoteCategory[];
  priorities: NotePriority[];
}

const NotesFilter: React.FC<NotesFilterProps> = ({ onFilter, categories, priorities }) => {
  const [isExpanded, setIsExpanded] = useState(false);
  const [filters, setFilters] = useState<NoteFilters>({
    search: '',
    category: undefined,
    priority: undefined,
    isRead: undefined,
    startDate: undefined,
    endDate: undefined,
  });

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value, type } = e.target as HTMLInputElement & { name: string };
    
    if (type === 'checkbox') {
      const checkbox = e.target as HTMLInputElement;
      setFilters(prev => ({ ...prev, [name]: checkbox.checked }));
    } else if (value === '') {
      // If value is empty string, set it to undefined to remove the filter
      setFilters(prev => {
        const newFilters = { ...prev };
        delete newFilters[name as keyof NoteFilters];
        return newFilters;
      });
    } else {
      setFilters(prev => ({ ...prev, [name]: value }));
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onFilter(filters);
  };

  const handleReset = () => {
    setFilters({
      search: '',
      category: undefined,
      priority: undefined,
      isRead: undefined,
      startDate: undefined,
      endDate: undefined,
    });
    onFilter({});
  };

  const categoryOptions = [
    { value: '', label: 'Tüm Kategoriler' },
    ...categories.map(category => {
      const labelMap: Record<NoteCategory, string> = {
        orders: 'Siparişler',
        inventory: 'Stok',
        customer: 'Müşteri',
        marketing: 'Pazarlama',
        other: 'Diğer'
      };
      
      return { value: category, label: labelMap[category] };
    })
  ];
  
  const priorityOptions = [
    { value: '', label: 'Tüm Öncelikler' },
    ...priorities.map(priority => {
      const labelMap: Record<NotePriority, string> = {
        urgent: 'Acil',
        normal: 'Normal',
        info: 'Bilgi'
      };
      
      return { value: priority, label: labelMap[priority] };
    })
  ];

  return (
    <div className="bg-white rounded-lg shadow-sm mb-4 overflow-hidden">
      <div className="p-3 border-b">
        <form onSubmit={handleSubmit}>
          <div className="flex items-center space-x-2">
            <div className="flex-grow">
              <Input
                name="search"
                value={filters.search || ''}
                onChange={handleChange}
                placeholder="Notlarda ara..."
                icon={<Search size={18} />}
                className="m-0"
              />
            </div>
            
            <Button 
              type="button"
              variant="ghost"
              size="sm"
              icon={<Filter size={18} />}
              onClick={() => setIsExpanded(!isExpanded)}
              className={isExpanded ? 'bg-gray-100' : ''}
            >
              Filtrele
            </Button>
            
            <Button 
              type="submit"
              variant="primary"
              size="sm"
            >
              Ara
            </Button>
          </div>
          
          {isExpanded && (
            <div className="mt-3 pt-3 border-t grid grid-cols-1 md:grid-cols-3 gap-3">
              <div>
                <label htmlFor="category" className="block text-sm font-medium text-gray-700 mb-1">
                  Kategori
                </label>
                <select
                  id="category"
                  name="category"
                  value={filters.category || ''}
                  onChange={handleChange}
                  className="block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                >
                  {categoryOptions.map(option => (
                    <option key={option.value} value={option.value}>
                      {option.label}
                    </option>
                  ))}
                </select>
              </div>
              
              <div>
                <label htmlFor="priority" className="block text-sm font-medium text-gray-700 mb-1">
                  Öncelik
                </label>
                <select
                  id="priority"
                  name="priority"
                  value={filters.priority || ''}
                  onChange={handleChange}
                  className="block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                >
                  {priorityOptions.map(option => (
                    <option key={option.value} value={option.value}>
                      {option.label}
                    </option>
                  ))}
                </select>
              </div>
              
              <div>
                <label htmlFor="isRead" className="block text-sm font-medium text-gray-700 mb-1">
                  Okunma Durumu
                </label>
                <select
                  id="isRead"
                  name="isRead"
                  value={filters.isRead === undefined ? '' : filters.isRead ? 'true' : 'false'}
                  onChange={e => {
                    const value = e.target.value;
                    if (value === '') {
                      setFilters(prev => {
                        const newFilters = { ...prev };
                        delete newFilters.isRead;
                        return newFilters;
                      });
                    } else {
                      setFilters(prev => ({ ...prev, isRead: value === 'true' }));
                    }
                  }}
                  className="block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                >
                  <option value="">Tümü</option>
                  <option value="true">Okundu</option>
                  <option value="false">Okunmadı</option>
                </select>
              </div>
              
              <div>
                <label htmlFor="startDate" className="block text-sm font-medium text-gray-700 mb-1">
                  Başlangıç Tarihi
                </label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-gray-500">
                    <Calendar size={16} />
                  </div>
                  <input
                    type="date"
                    id="startDate"
                    name="startDate"
                    value={filters.startDate || ''}
                    onChange={handleChange}
                    className="block w-full pl-10 rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                  />
                </div>
              </div>
              
              <div>
                <label htmlFor="endDate" className="block text-sm font-medium text-gray-700 mb-1">
                  Bitiş Tarihi
                </label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-gray-500">
                    <Calendar size={16} />
                  </div>
                  <input
                    type="date"
                    id="endDate"
                    name="endDate"
                    value={filters.endDate || ''}
                    onChange={handleChange}
                    className="block w-full pl-10 rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                  />
                </div>
              </div>
              
              <div className="flex items-end">
                <Button
                  type="button"
                  variant="secondary"
                  size="sm"
                  icon={<X size={16} />}
                  onClick={handleReset}
                  className="mb-0"
                >
                  Filtreleri Temizle
                </Button>
              </div>
            </div>
          )}
        </form>
      </div>
    </div>
  );
};

export default NotesFilter;