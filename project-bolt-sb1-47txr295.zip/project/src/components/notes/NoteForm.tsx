import React, { useState, useRef } from 'react';
import { Note, NotePriority, NoteCategory } from '../../types';
import { useNotes } from '../../context/NoteContext';
import Button from '../ui/Button';
import Input from '../ui/Input';
import Textarea from '../ui/Textarea';
import { AlertCircle, Paperclip, Plus, X } from 'lucide-react';

interface NoteFormProps {
  note?: Note;
  onSave: () => void;
  onCancel: () => void;
}

const NoteForm: React.FC<NoteFormProps> = ({ note, onSave, onCancel }) => {
  const { addNote, updateNote, categories, priorities, uploadAttachment, removeAttachment } = useNotes();
  const fileInputRef = useRef<HTMLInputElement>(null);
  
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [formData, setFormData] = useState({
    title: note?.title || '',
    content: note?.content || '',
    priority: note?.priority || 'normal' as NotePriority,
    category: note?.category || 'other' as NoteCategory,
    tags: note?.tags?.join(', ') || '',
    attachments: note?.attachments || []
  });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [uploading, setUploading] = useState(false);
  
  const validateForm = () => {
    const newErrors: Record<string, string> = {};
    
    if (!formData.title.trim()) {
      newErrors.title = 'Başlık gereklidir';
    }
    
    if (!formData.content.trim()) {
      newErrors.content = 'İçerik gereklidir';
    }
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };
  
  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
    
    // Clear error when field is edited
    if (errors[name]) {
      setErrors(prev => {
        const newErrors = { ...prev };
        delete newErrors[name];
        return newErrors;
      });
    }
  };
  
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validateForm()) {
      return;
    }
    
    setIsSubmitting(true);
    
    try {
      const noteData = {
        title: formData.title,
        content: formData.content,
        priority: formData.priority,
        category: formData.category,
        tags: formData.tags.split(',').map(tag => tag.trim()).filter(Boolean),
        attachments: formData.attachments
      };
      
      if (note) {
        await updateNote(note.id, noteData);
      } else {
        await addNote(noteData);
      }
      
      onSave();
    } catch (error) {
      console.error('Error saving note:', error);
      setErrors({ form: 'Not kaydedilirken bir hata oluştu' });
    } finally {
      setIsSubmitting(false);
    }
  };
  
  const handleFileUpload = async () => {
    if (fileInputRef.current?.files?.length) {
      setUploading(true);
      
      try {
        const file = fileInputRef.current.files[0];
        const attachment = await uploadAttachment(file);
        
        setFormData(prev => ({
          ...prev,
          attachments: [...prev.attachments, attachment]
        }));
        
        // Reset file input
        if (fileInputRef.current) {
          fileInputRef.current.value = '';
        }
      } catch (error) {
        console.error('Error uploading file:', error);
        setErrors({ attachment: 'Dosya yüklenirken bir hata oluştu' });
      } finally {
        setUploading(false);
      }
    }
  };
  
  const handleRemoveAttachment = async (attachmentId: string) => {
    if (note) {
      try {
        await removeAttachment(note.id, attachmentId);
      } catch (error) {
        console.error('Error removing attachment:', error);
      }
    }
    
    setFormData(prev => ({
      ...prev,
      attachments: prev.attachments.filter(a => a.id !== attachmentId)
    }));
  };
  
  const categoryOptions = categories.map(category => {
    const labelMap: Record<NoteCategory, string> = {
      orders: 'Siparişler',
      inventory: 'Stok',
      customer: 'Müşteri',
      marketing: 'Pazarlama',
      other: 'Diğer'
    };
    
    return { value: category, label: labelMap[category] };
  });
  
  const priorityOptions = priorities.map(priority => {
    const labelMap: Record<NotePriority, string> = {
      urgent: 'Acil',
      normal: 'Normal',
      info: 'Bilgi'
    };
    
    return { value: priority, label: labelMap[priority] };
  });
  
  return (
    <form onSubmit={handleSubmit} className="space-y-4 p-4">
      <Input
        label="Başlık"
        name="title"
        value={formData.title}
        onChange={handleChange}
        error={errors.title}
        placeholder="Not başlığı"
        required
      />
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <label htmlFor="category" className="block text-sm font-medium text-gray-700 mb-1">
            Kategori
          </label>
          <select
            id="category"
            name="category"
            value={formData.category}
            onChange={handleChange}
            className="block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
          >
            {categoryOptions.map(option => (
              <option key={option.value} value={option.value}>
                {option.label}
              </option>
            ))}
          </select>
        </div>
        
        <div>
          <label htmlFor="priority" className="block text-sm font-medium text-gray-700 mb-1">
            Öncelik
          </label>
          <select
            id="priority"
            name="priority"
            value={formData.priority}
            onChange={handleChange}
            className="block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
          >
            {priorityOptions.map(option => (
              <option key={option.value} value={option.value}>
                {option.label}
              </option>
            ))}
          </select>
        </div>
      </div>
      
      <Textarea
        label="İçerik"
        name="content"
        value={formData.content}
        onChange={handleChange}
        error={errors.content}
        placeholder="Not içeriği"
        rows={6}
        required
      />
      
      <Input
        label="Etiketler (virgülle ayırın)"
        name="tags"
        value={formData.tags}
        onChange={handleChange}
        placeholder="örn: sipariş, müşteri, acil"
      />
      
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-1">
          Ekler
        </label>
        
        <div className="mt-1 mb-3">
          <div className="flex items-center">
            <input
              type="file"
              ref={fileInputRef}
              className="hidden"
              onChange={handleFileUpload}
            />
            <Button
              type="button"
              variant="secondary"
              size="sm"
              icon={<Paperclip size={16} />}
              onClick={() => fileInputRef.current?.click()}
              isLoading={uploading}
            >
              Dosya Ekle
            </Button>
          </div>
          
          {errors.attachment && (
            <p className="mt-1 text-sm text-red-600">{errors.attachment}</p>
          )}
        </div>
        
        {formData.attachments.length > 0 && (
          <div className="space-y-2 mb-4">
            {formData.attachments.map(attachment => (
              <div key={attachment.id} className="flex items-center p-2 bg-gray-50 rounded">
                <div className="flex-1 truncate">
                  <span className="font-medium">{attachment.filename}</span>
                  <span className="ml-2 text-sm text-gray-500">
                    ({(attachment.size / 1024).toFixed(1)} KB)
                  </span>
                </div>
                <button
                  type="button"
                  onClick={() => handleRemoveAttachment(attachment.id)}
                  className="text-gray-400 hover:text-red-500"
                  aria-label="Dosyayı kaldır"
                >
                  <X size={16} />
                </button>
              </div>
            ))}
          </div>
        )}
      </div>
      
      {errors.form && (
        <div className="p-3 bg-red-50 text-red-700 rounded flex items-center">
          <AlertCircle size={18} className="mr-2" />
          {errors.form}
        </div>
      )}
      
      <div className="flex justify-end space-x-3 mt-6">
        <Button
          type="button"
          variant="ghost"
          onClick={onCancel}
        >
          İptal
        </Button>
        <Button
          type="submit"
          variant="primary"
          isLoading={isSubmitting}
          icon={<Plus size={16} />}
        >
          {note ? 'Notu Güncelle' : 'Not Ekle'}
        </Button>
      </div>
    </form>
  );
};

export default NoteForm;