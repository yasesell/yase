import React from 'react';
import { Note } from '../../types';
import Badge from '../ui/Badge';
import { Calendar, Eye, EyeOff, Paperclip, Tag } from 'lucide-react';
import { useNotes } from '../../context/NoteContext';

interface NoteCardProps {
  note: Note;
  onClick?: () => void;
}

const NoteCard: React.FC<NoteCardProps> = ({ note, onClick }) => {
  const { toggleReadStatus } = useNotes();

  const priorityMap = {
    urgent: { variant: 'danger', label: 'Acil' },
    normal: { variant: 'primary', label: 'Normal' },
    info: { variant: 'info', label: 'Bilgi' }
  };

  const categoryMap = {
    orders: { label: 'Siparişler' },
    inventory: { label: 'Stok' },
    customer: { label: 'Müşteri' },
    marketing: { label: 'Pazarlama' },
    other: { label: 'Diğer' }
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return new Intl.DateTimeFormat('tr-TR', { 
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    }).format(date);
  };

  const handleToggleRead = (e: React.MouseEvent) => {
    e.stopPropagation();
    toggleReadStatus(note.id);
  };

  return (
    <div 
      className={`
        p-4 mb-4 border rounded-lg shadow-sm transition-all duration-200 hover:shadow-md cursor-pointer
        ${note.isRead ? 'bg-white' : 'bg-blue-50'}
        ${note.priority === 'urgent' ? 'border-l-4 border-l-red-500' : ''}
      `}
      onClick={onClick}
    >
      <div className="flex justify-between items-start mb-2">
        <h3 className={`text-lg font-medium ${note.isRead ? '' : 'font-semibold'}`}>{note.title}</h3>
        <div className="flex items-center space-x-2">
          <Badge 
            variant={priorityMap[note.priority].variant as any} 
            size="sm"
          >
            {priorityMap[note.priority].label}
          </Badge>
          <button 
            onClick={handleToggleRead}
            className="text-gray-500 hover:text-gray-700"
            aria-label={note.isRead ? "Okunmadı olarak işaretle" : "Okundu olarak işaretle"}
          >
            {note.isRead ? <EyeOff size={16} /> : <Eye size={16} />}
          </button>
        </div>
      </div>
      
      <p className="text-gray-600 mb-3 line-clamp-2">{note.content}</p>
      
      <div className="flex flex-wrap items-center text-sm text-gray-500 gap-3">
        <div className="flex items-center">
          <Calendar size={14} className="mr-1" />
          {formatDate(note.createdAt)}
        </div>
        
        <div>
          <span className="font-medium">{note.authorName}</span>
        </div>
        
        <Badge variant="default" size="sm">
          {categoryMap[note.category].label}
        </Badge>
        
        {note.attachments.length > 0 && (
          <div className="flex items-center">
            <Paperclip size={14} className="mr-1" />
            {note.attachments.length}
          </div>
        )}
        
        {note.tags.length > 0 && (
          <div className="flex items-center">
            <Tag size={14} className="mr-1" />
            {note.tags.map((tag, index) => (
              <span key={index} className="mr-1 last:mr-0">
                {tag}{index < note.tags.length - 1 ? ',' : ''}
              </span>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default NoteCard;