import React, { useState } from 'react';
import { Note, Attachment } from '../../types';
import { useNotes } from '../../context/NoteContext';
import Button from '../ui/Button';
import Badge from '../ui/Badge';
import { Calendar, User, Tag, Paperclip, Edit, Trash2, Download } from 'lucide-react';
import NoteForm from './NoteForm';

interface NoteDetailProps {
  note: Note;
  onClose: () => void;
}

const NoteDetail: React.FC<NoteDetailProps> = ({ note, onClose }) => {
  const [isEditing, setIsEditing] = useState(false);
  const { deleteNote, markAsRead } = useNotes();

  const priorityMap = {
    urgent: { variant: 'danger', label: 'Acil' },
    normal: { variant: 'primary', label: 'Normal' },
    info: { variant: 'info', label: 'Bilgi' }
  };

  const categoryMap = {
    orders: { label: 'Siparişler' },
    inventory: { label: 'Stok' },
    customer: { label: 'Müşteri' },
    marketing: { label: 'Pazarlama' },
    other: { label: 'Diğer' }
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return new Intl.DateTimeFormat('tr-TR', { 
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    }).format(date);
  };

  const handleDelete = async () => {
    if (confirm('Bu notu silmek istediğinizden emin misiniz?')) {
      await deleteNote(note.id);
      onClose();
    }
  };

  const handleEdit = () => {
    setIsEditing(true);
  };

  React.useEffect(() => {
    if (!note.isRead) {
      markAsRead(note.id);
    }
  }, [note.id, note.isRead, markAsRead]);

  if (isEditing) {
    return <NoteForm note={note} onCancel={() => setIsEditing(false)} onSave={() => setIsEditing(false)} />;
  }

  return (
    <div className="p-4">
      <div className="flex justify-between items-start mb-4">
        <h2 className="text-2xl font-bold">{note.title}</h2>
        <div className="flex space-x-2">
          <Button
            variant="ghost"
            size="sm"
            icon={<Edit size={16} />}
            onClick={handleEdit}
          >
            Düzenle
          </Button>
          <Button
            variant="danger"
            size="sm"
            icon={<Trash2 size={16} />}
            onClick={handleDelete}
          >
            Sil
          </Button>
        </div>
      </div>

      <div className="flex flex-wrap gap-3 mb-4">
        <Badge variant={priorityMap[note.priority].variant as any}>
          {priorityMap[note.priority].label}
        </Badge>
        <Badge variant="default">
          {categoryMap[note.category].label}
        </Badge>
      </div>

      <div className="flex flex-wrap gap-4 text-sm text-gray-500 mb-6">
        <div className="flex items-center">
          <Calendar size={16} className="mr-1" />
          {formatDate(note.createdAt)}
        </div>
        <div className="flex items-center">
          <User size={16} className="mr-1" />
          {note.authorName}
        </div>
        {note.updatedAt !== note.createdAt && (
          <div>
            Son güncelleme: {formatDate(note.updatedAt)}
          </div>
        )}
      </div>

      <div className="bg-white p-4 rounded-lg shadow-sm mb-6 whitespace-pre-wrap">
        {note.content}
      </div>

      {note.tags.length > 0 && (
        <div className="mb-6">
          <div className="flex items-center mb-2">
            <Tag size={16} className="mr-2" />
            <span className="font-medium">Etiketler:</span>
          </div>
          <div className="flex flex-wrap gap-2">
            {note.tags.map((tag, index) => (
              <Badge key={index} variant="default" size="sm">
                {tag}
              </Badge>
            ))}
          </div>
        </div>
      )}

      {note.attachments.length > 0 && (
        <div>
          <div className="flex items-center mb-2">
            <Paperclip size={16} className="mr-2" />
            <span className="font-medium">Ekler:</span>
          </div>
          <div className="space-y-2">
            {note.attachments.map((attachment: Attachment) => (
              <div key={attachment.id} className="flex items-center p-2 bg-gray-50 rounded">
                <div className="flex-1">
                  <div className="font-medium">{attachment.filename}</div>
                  <div className="text-sm text-gray-500">
                    {(attachment.size / 1024).toFixed(1)} KB
                  </div>
                </div>
                <Button
                  variant="ghost"
                  size="sm"
                  icon={<Download size={16} />}
                  onClick={() => window.open(attachment.url, '_blank')}
                >
                  İndir
                </Button>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

export default NoteDetail;