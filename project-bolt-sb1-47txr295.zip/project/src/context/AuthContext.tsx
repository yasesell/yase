import React, { createContext, useContext, useState, useEffect } from 'react';
import { AuthState, User } from '../types';

interface AuthContextType extends AuthState {
  login: (username: string, password: string) => Promise<void>;
  logout: () => void;
  verify2FA: (code: string) => Promise<boolean>;
}

const defaultState: AuthState = {
  user: null,
  isAuthenticated: false,
  isLoading: true,
  error: null,
};

// For demo purposes, we'll use these mock users
const MOCK_USERS = [
  { 
    id: '1', 
    username: 'admin1', 
    password: 'password1', 
    email: 'admin1@example.com',
    avatar: 'https://i.pravatar.cc/150?img=1'
  },
  { 
    id: '2', 
    username: 'admin2', 
    password: 'password2', 
    email: 'admin2@example.com',
    avatar: 'https://i.pravatar.cc/150?img=2'
  }
];

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [state, setState] = useState<AuthState>(defaultState);
  const [twoFactorPending, setTwoFactorPending] = useState<boolean>(false);
  const [pendingUser, setPendingUser] = useState<User | null>(null);

  useEffect(() => {
    // Check for existing session
    const storedUser = localStorage.getItem('user');
    if (storedUser) {
      try {
        const user = JSON.parse(storedUser);
        setState({
          user,
          isAuthenticated: true,
          isLoading: false,
          error: null,
        });
      } catch (e) {
        localStorage.removeItem('user');
        setState({...defaultState, isLoading: false});
      }
    } else {
      setState({...defaultState, isLoading: false});
    }
  }, []);

  const login = async (username: string, password: string) => {
    setState({...state, isLoading: true, error: null});
    
    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      const user = MOCK_USERS.find(u => u.username === username && u.password === password);
      
      if (!user) {
        throw new Error('Geçersiz kullanıcı adı veya şifre');
      }
      
      // Simulate 2FA requirement
      const { password: _, ...safeUser } = user;
      setPendingUser(safeUser as User);
      setTwoFactorPending(true);
      setState({...state, isLoading: false});
      
    } catch (error) {
      setState({
        ...state,
        isLoading: false,
        error: error instanceof Error ? error.message : 'Bir hata oluştu',
      });
    }
  };

  const verify2FA = async (code: string) => {
    setState({...state, isLoading: true, error: null});
    
    try {
      // Simulate API verification
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      // For demo, we'll accept any 6-digit code
      if (code.length !== 6 || !/^\d+$/.test(code)) {
        throw new Error('Geçersiz doğrulama kodu');
      }
      
      if (!pendingUser) {
        throw new Error('Oturum zaman aşımına uğradı');
      }
      
      localStorage.setItem('user', JSON.stringify(pendingUser));
      
      setState({
        user: pendingUser,
        isAuthenticated: true,
        isLoading: false,
        error: null,
      });
      
      setTwoFactorPending(false);
      setPendingUser(null);
      return true;
      
    } catch (error) {
      setState({
        ...state,
        isLoading: false,
        error: error instanceof Error ? error.message : 'Bir hata oluştu',
      });
      return false;
    }
  };
  
  const logout = () => {
    localStorage.removeItem('user');
    setState({
      user: null,
      isAuthenticated: false,
      isLoading: false,
      error: null,
    });
  };

  return (
    <AuthContext.Provider value={{
      ...state,
      login,
      logout,
      verify2FA,
    }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = (): AuthContextType => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};