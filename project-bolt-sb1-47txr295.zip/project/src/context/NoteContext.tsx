import React, { createContext, useContext, useState, useEffect } from 'react';
import { Note, NoteFilters, NotePriority, NoteCategory, Attachment } from '../types';
import { useAuth } from './AuthContext';

interface NoteContextType {
  notes: Note[];
  isLoading: boolean;
  error: string | null;
  addNote: (note: Omit<Note, 'id' | 'createdAt' | 'updatedAt' | 'authorId' | 'authorName' | 'isRead'>) => Promise<Note>;
  updateNote: (id: string, updates: Partial<Note>) => Promise<Note>;
  deleteNote: (id: string) => Promise<void>;
  markAsRead: (id: string) => Promise<void>;
  toggleReadStatus: (id: string) => Promise<void>;
  getNoteById: (id: string) => Note | undefined;
  filterNotes: (filters: NoteFilters) => Note[];
  uploadAttachment: (file: File) => Promise<Attachment>;
  removeAttachment: (noteId: string, attachmentId: string) => Promise<void>;
  categories: NoteCategory[];
  priorities: NotePriority[];
}

// Initial mock data
const MOCK_NOTES: Note[] = [
  {
    id: '1',
    title: 'Amazon Sipariş Problemi',
    content: 'Müşteri #12345 siparişinin gecikmesinden şikayetçi. Lütfen acil ilgilenin.',
    createdAt: '2025-05-10T10:30:00Z',
    updatedAt: '2025-05-10T10:30:00Z',
    authorId: '1',
    authorName: 'admin1',
    priority: 'urgent',
    category: 'orders',
    isRead: false,
    attachments: [],
    tags: ['sipariş', 'gecikme', 'müşteri']
  },
  {
    id: '2',
    title: 'Stok Güncelleme',
    content: 'Elektronik kategorisinde stok güncellendi. Yeni ürünler kataloga eklendi.',
    createdAt: '2025-05-09T14:15:00Z',
    updatedAt: '2025-05-09T14:15:00Z',
    authorId: '2',
    authorName: 'admin2',
    priority: 'normal',
    category: 'inventory',
    isRead: true,
    attachments: [],
    tags: ['stok', 'elektronik', 'katalog']
  },
  {
    id: '3',
    title: 'Olumlu Müşteri Geri Bildirimi',
    content: 'Müşteri #54321 hızlı kargo ve kaliteli ürünler için teşekkür etti.',
    createdAt: '2025-05-08T09:45:00Z',
    updatedAt: '2025-05-08T09:45:00Z',
    authorId: '1',
    authorName: 'admin1',
    priority: 'info',
    category: 'customer',
    isRead: false,
    attachments: [],
    tags: ['müşteri', 'geri bildirim', 'olumlu']
  }
];

const CATEGORIES: NoteCategory[] = ['orders', 'inventory', 'customer', 'marketing', 'other'];
const PRIORITIES: NotePriority[] = ['urgent', 'normal', 'info'];

const NoteContext = createContext<NoteContextType | undefined>(undefined);

export const NoteProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { user } = useAuth();
  const [notes, setNotes] = useState<Note[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    // Load notes from localStorage or use mock data for demo
    const loadNotes = async () => {
      setIsLoading(true);
      try {
        const storedNotes = localStorage.getItem('notes');
        if (storedNotes) {
          setNotes(JSON.parse(storedNotes));
        } else {
          // Use mock data for initial demo
          setNotes(MOCK_NOTES);
          localStorage.setItem('notes', JSON.stringify(MOCK_NOTES));
        }
      } catch (error) {
        setError('Notlar yüklenirken bir hata oluştu');
        console.error(error);
      } finally {
        setIsLoading(false);
      }
    };

    loadNotes();
  }, []);

  // Save notes to localStorage whenever they change
  useEffect(() => {
    if (notes.length > 0) {
      localStorage.setItem('notes', JSON.stringify(notes));
    }
  }, [notes]);

  const addNote = async (noteData: Omit<Note, 'id' | 'createdAt' | 'updatedAt' | 'authorId' | 'authorName' | 'isRead'>): Promise<Note> => {
    if (!user) throw new Error('Kullanıcı oturum açmış olmalıdır');
    
    const now = new Date().toISOString();
    const newNote: Note = {
      id: Date.now().toString(),
      ...noteData,
      createdAt: now,
      updatedAt: now,
      authorId: user.id,
      authorName: user.username,
      isRead: false
    };

    setNotes(prevNotes => [newNote, ...prevNotes]);
    return newNote;
  };

  const updateNote = async (id: string, updates: Partial<Note>): Promise<Note> => {
    const noteIndex = notes.findIndex(note => note.id === id);
    if (noteIndex === -1) throw new Error('Not bulunamadı');

    const updatedNote = {
      ...notes[noteIndex],
      ...updates,
      updatedAt: new Date().toISOString()
    };

    const updatedNotes = [...notes];
    updatedNotes[noteIndex] = updatedNote;
    setNotes(updatedNotes);

    return updatedNote;
  };

  const deleteNote = async (id: string): Promise<void> => {
    setNotes(prevNotes => prevNotes.filter(note => note.id !== id));
  };

  const markAsRead = async (id: string): Promise<void> => {
    const noteIndex = notes.findIndex(note => note.id === id);
    if (noteIndex !== -1 && !notes[noteIndex].isRead) {
      updateNote(id, { isRead: true });
    }
  };

  const toggleReadStatus = async (id: string): Promise<void> => {
    const note = notes.find(note => note.id === id);
    if (note) {
      updateNote(id, { isRead: !note.isRead });
    }
  };

  const getNoteById = (id: string): Note | undefined => {
    return notes.find(note => note.id === id);
  };

  const filterNotes = (filters: NoteFilters): Note[] => {
    return notes.filter(note => {
      // Filter by search text
      if (filters.search && !note.title.toLowerCase().includes(filters.search.toLowerCase()) && 
          !note.content.toLowerCase().includes(filters.search.toLowerCase())) {
        return false;
      }

      // Filter by category
      if (filters.category && note.category !== filters.category) {
        return false;
      }

      // Filter by priority
      if (filters.priority && note.priority !== filters.priority) {
        return false;
      }

      // Filter by read status
      if (filters.isRead !== undefined && note.isRead !== filters.isRead) {
        return false;
      }

      // Filter by date range
      if (filters.startDate && new Date(note.createdAt) < new Date(filters.startDate)) {
        return false;
      }

      if (filters.endDate && new Date(note.createdAt) > new Date(filters.endDate)) {
        return false;
      }

      // Filter by author
      if (filters.authorId && note.authorId !== filters.authorId) {
        return false;
      }

      return true;
    });
  };

  const uploadAttachment = async (file: File): Promise<Attachment> => {
    // In a real app, you would upload the file to a server or cloud storage
    // For demo, we'll create a mock attachment
    return new Promise(resolve => {
      setTimeout(() => {
        const attachment: Attachment = {
          id: Date.now().toString(),
          filename: file.name,
          url: URL.createObjectURL(file), // This creates a local object URL
          type: file.type,
          size: file.size
        };
        resolve(attachment);
      }, 1000);
    });
  };

  const removeAttachment = async (noteId: string, attachmentId: string): Promise<void> => {
    const note = notes.find(note => note.id === noteId);
    if (!note) throw new Error('Not bulunamadı');

    const updatedAttachments = note.attachments.filter(att => att.id !== attachmentId);
    await updateNote(noteId, { attachments: updatedAttachments });
  };

  return (
    <NoteContext.Provider value={{
      notes,
      isLoading,
      error,
      addNote,
      updateNote,
      deleteNote,
      markAsRead,
      toggleReadStatus,
      getNoteById,
      filterNotes,
      uploadAttachment,
      removeAttachment,
      categories: CATEGORIES,
      priorities: PRIORITIES
    }}>
      {children}
    </NoteContext.Provider>
  );
};

export const useNotes = (): NoteContextType => {
  const context = useContext(NoteContext);
  if (context === undefined) {
    throw new Error('useNotes must be used within a NoteProvider');
  }
  return context;
};